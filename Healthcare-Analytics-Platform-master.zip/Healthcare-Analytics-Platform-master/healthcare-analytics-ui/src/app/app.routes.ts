import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Dashboard } from './pages/dashboard/dashboard';
import { Patients } from './pages/patients/patients';
import { Doctors } from './pages/doctors/doctors';
import { Appointments } from './pages/appointments/appointments';
import { authGuard } from './guards/auth-guard';


export const routes: Routes = [
  {
    path: '',
    component: Login
  },

  {
    path: 'dashboard',
    component: Dashboard,
    canActivate: [authGuard]
  },

  {
    path: 'patients',
    component: Patients,
    canActivate: [authGuard]
  },

  {
    path: 'doctors',
    component: Doctors,
    canActivate: [authGuard]
  },

  {
    path: 'appointments',
    component: Appointments,
    canActivate: [authGuard]
  }
];