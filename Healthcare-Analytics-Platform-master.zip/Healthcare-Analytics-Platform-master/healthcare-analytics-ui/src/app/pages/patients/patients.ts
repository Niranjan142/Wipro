import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Patient } from '../../services/patient';
import * as XLSX from 'xlsx';
@Component({
  selector: 'app-patients',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './patients.html',
  styleUrl: './patients.css'
})
export class Patients {
  patients: any[] = [];
  errorMessage = '';
  searchText = '';

  role = localStorage.getItem('role');

  isEditMode = false;
  selectedPatientId = 0;

  newPatient = {
    fullName: '',
    age: '',
    gender: '',
    phoneNumber: '',
    email: '',
    address: ''
  };
exportPatientsToExcel(): void {
  const exportData = this.filteredPatients.map(patient => ({
    Id: patient.patientId,
    FullName: patient.fullName,
    Age: patient.age,
    Gender: patient.gender,
    Phone: patient.phoneNumber,
    Email: patient.email,
    Address: patient.address
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Patients');

  XLSX.writeFile(workbook, 'Patients_Report.xlsx');
}
  constructor(private patientService: Patient) {}

  ngOnInit(): void {
    this.loadPatients();
  }

  isAdmin(): boolean {
    return this.role === 'Admin';
  }

  loadPatients(): void {
    this.patientService.getPatients().subscribe({
      next: (data) => {
        this.patients = data;
      },
      error: () => {
        this.errorMessage = 'Unable to load patients';
      }
    });
  }

  get filteredPatients(): any[] {
    if (!this.searchText) {
      return this.patients;
    }

    const search = this.searchText.toLowerCase();

    return this.patients.filter(patient =>
      patient.fullName.toLowerCase().includes(search) ||
      patient.email.toLowerCase().includes(search) ||
      patient.phoneNumber.includes(search) ||
      patient.gender.toLowerCase().includes(search) ||
      patient.address.toLowerCase().includes(search)
    );
  }

  savePatient(): void {
    if (
      !this.newPatient.fullName ||
      !this.newPatient.age ||
      !this.newPatient.gender ||
      !this.newPatient.phoneNumber ||
      !this.newPatient.email ||
      !this.newPatient.address
    ) {
      this.errorMessage = 'Please add all patient details';
      return;
    }

    if (!/^\d{10}$/.test(this.newPatient.phoneNumber)) {
      this.errorMessage = 'Phone number must be exactly 10 digits';
      return;
    }

    if (Number(this.newPatient.age) <= 0) {
      this.errorMessage = 'Age must be greater than 0';
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.newPatient.email)) {
      this.errorMessage = 'Please enter a valid email address';
      return;
    }

    if (this.isEditMode) {
      this.updatePatient();
      return;
    }

    this.patientService.addPatient(this.newPatient).subscribe({
      next: () => {
        this.loadPatients();
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Unable to add patient';
      }
    });
  }

  editPatient(patient: any): void {
    this.isEditMode = true;
    this.selectedPatientId = patient.patientId;

    this.newPatient = {
      fullName: patient.fullName,
      age: patient.age,
      gender: patient.gender,
      phoneNumber: patient.phoneNumber,
      email: patient.email,
      address: patient.address
    };
  }

  updatePatient(): void {
    this.patientService.updatePatient(this.selectedPatientId, this.newPatient).subscribe({
      next: () => {
        this.loadPatients();
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Unable to update patient';
      }
    });
  }

  deletePatient(id: number): void {
    if (!confirm('Delete this patient?')) {
      return;
    }

    this.patientService.deletePatient(id).subscribe({
      next: () => {
        this.loadPatients();
      },
      error: () => {
        this.errorMessage = 'Unable to delete patient';
      }
    });
  }

  resetForm(): void {
    this.errorMessage = '';
    this.isEditMode = false;
    this.selectedPatientId = 0;

    this.newPatient = {
      fullName: '',
      age: '',
      gender: '',
      phoneNumber: '',
      email: '',
      address: ''
    };
  }
}