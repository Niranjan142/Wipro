import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Patient } from '../../services/patient';
import { Doctor } from '../../services/doctor';
import { Appointment } from '../../services/appointment';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
 imports: [RouterLink, CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard {
  username = localStorage.getItem('username');
  role = localStorage.getItem('role');
  isDarkMode = localStorage.getItem('theme') === 'dark';
  totalPatients = 0;
  totalDoctors = 0;
  totalAppointments = 0;
  malePatients = 0;
femalePatients = 0;
otherPatients = 0;

scheduledAppointments = 0;
completedAppointments = 0;
cancelledAppointments = 0;

specializationCounts: any[] = [];
  constructor(
    private patientService: Patient,
    private doctorService: Doctor,
    private appointmentService: Appointment,
    private router: Router
  ) {}

toggleTheme(): void {
  this.isDarkMode = !this.isDarkMode;

  if (this.isDarkMode) {
    document.body.classList.add('dark-mode');
    localStorage.setItem('theme', 'dark');
  } else {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('theme', 'light');
  }
}

  ngOnInit(): void {
  if (this.isDarkMode) {
    document.body.classList.add('dark-mode');
  }

  this.loadDashboardCounts();
}

loadDashboardCounts(): void {
  this.patientService.getPatients().subscribe({
    next: (data) => {
      this.totalPatients = data.length;

      this.malePatients = data.filter((p: any) => p.gender === 'Male').length;
      this.femalePatients = data.filter((p: any) => p.gender === 'Female').length;
      this.otherPatients = data.filter((p: any) => p.gender === 'Other').length;
    }
  });

  this.doctorService.getDoctors().subscribe({
    next: (data) => {
      this.totalDoctors = data.length;

      const counts: any = {};

      data.forEach((doctor: any) => {
        counts[doctor.specialization] = (counts[doctor.specialization] || 0) + 1;
      });

      this.specializationCounts = Object.keys(counts).map(key => ({
        name: key,
        count: counts[key]
      }));
    }
  });

  this.appointmentService.getAppointments().subscribe({
    next: (data) => {
      this.totalAppointments = data.length;

      this.scheduledAppointments = data.filter((a: any) => a.status === 'Scheduled').length;
      this.completedAppointments = data.filter((a: any) => a.status === 'Completed').length;
      this.cancelledAppointments = data.filter((a: any) => a.status === 'Cancelled').length;
    }
  });
}

  logout(): void {
  localStorage.clear();
  this.router.navigate(['/']);
}
}