import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  username = '';
  password = '';
  role = 'Admin';
  errorMessage = '';

  constructor(private auth: Auth, private router: Router) {}

  login(): void {
    const user = {
      username: this.username,
      password: this.password,
      role: this.role
    };

    this.auth.login(user).subscribe({
      next: (response) => {
        this.auth.saveToken(response.token);
        localStorage.setItem('username', response.username);
        localStorage.setItem('role', response.role);
        this.router.navigate(['/dashboard']);
      },
      error: () => {
        this.errorMessage = 'Invalid username, password, or role';
      }
    });
  }
}