import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Appointment } from '../../services/appointment';
import { Patient } from '../../services/patient';
import { Doctor } from '../../services/doctor';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './appointments.html',
  styleUrl: './appointments.css'
})
export class Appointments {
  appointments: any[] = [];
  patients: any[] = [];
  doctors: any[] = [];

  errorMessage = '';
  searchText = '';

  role = localStorage.getItem('role');

  isEditMode = false;
  selectedAppointmentId = 0;

  newAppointment = {
    patientId: '',
    doctorId: '',
    appointmentDate: '',
    status: 'Scheduled'
  };

  constructor(
    private appointmentService: Appointment,
    private patientService: Patient,
    private doctorService: Doctor
  ) {}

  ngOnInit(): void {
    this.loadAppointments();
    this.loadPatients();
    this.loadDoctors();
  }

  isAdmin(): boolean {
    return this.role === 'Admin';
  }

  loadAppointments(): void {
    this.appointmentService.getAppointments().subscribe({
      next: (data) => {
        this.appointments = data;
      },
      error: () => {
        this.errorMessage = 'Unable to load appointments';
      }
    });
  }

  loadPatients(): void {
    this.patientService.getPatients().subscribe({
      next: (data) => {
        this.patients = data;
      }
    });
  }

  loadDoctors(): void {
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
      }
    });
  }
quickUpdateStatus(appointment: any, status: string): void {
  const appointmentData = {
    patientId: appointment.patientId,
    doctorId: appointment.doctorId,
    appointmentDate: appointment.appointmentDate,
    status: status
  };

  this.appointmentService
    .updateAppointment(appointment.appointmentId, appointmentData)
    .subscribe({
      next: () => {
        this.loadAppointments();
      },
      error: () => {
        this.errorMessage = 'Unable to update appointment status';
      }
    });
}
  get filteredAppointments(): any[] {
    if (!this.searchText) {
      return this.appointments;
    }

    const search = this.searchText.toLowerCase();

    return this.appointments.filter(a =>
      a.patientName?.toLowerCase().includes(search) ||
      a.doctorName?.toLowerCase().includes(search) ||
      a.doctorSpecialization?.toLowerCase().includes(search) ||
      a.status?.toLowerCase().includes(search)
    );
  }

 saveAppointment(): void {
  if (
    !this.newAppointment.patientId ||
    !this.newAppointment.doctorId ||
    !this.newAppointment.appointmentDate ||
    !this.newAppointment.status
  ) {
    this.errorMessage = 'Please add all appointment details';
    return;
  }

  const selectedDate = new Date(this.newAppointment.appointmentDate);
  const currentDate = new Date();

  if (selectedDate <= currentDate) {
    this.errorMessage = 'Appointment date and time must be in the future';
    return;
  }

  const appointmentData = {
    patientId: Number(this.newAppointment.patientId),
    doctorId: Number(this.newAppointment.doctorId),
    appointmentDate: this.newAppointment.appointmentDate,
    status: this.newAppointment.status
  };

  if (this.isEditMode) {
    this.updateAppointment(appointmentData);
    return;
  }

  this.appointmentService.addAppointment(appointmentData).subscribe({
    next: () => {
      this.loadAppointments();
      this.resetForm();
    },
    error: () => {
      this.errorMessage = 'Unable to add appointment';
    }
  });
}

  editAppointment(appointment: any): void {
    this.isEditMode = true;
    this.selectedAppointmentId = appointment.appointmentId;

    this.newAppointment = {
      patientId: appointment.patientId,
      doctorId: appointment.doctorId,
      appointmentDate: appointment.appointmentDate.slice(0, 16),
      status: appointment.status
    };
  }

  updateAppointment(appointmentData: any): void {
    this.appointmentService.updateAppointment(this.selectedAppointmentId, appointmentData).subscribe({
      next: () => {
        this.loadAppointments();
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Unable to update appointment';
      }
    });
  }

  deleteAppointment(id: number): void {
    if (!confirm('Delete this appointment?')) {
      return;
    }

    this.appointmentService.deleteAppointment(id).subscribe({
      next: () => {
        this.loadAppointments();
      },
      error: () => {
        this.errorMessage = 'Unable to delete appointment';
      }
    });
  }

  resetForm(): void {
    this.errorMessage = '';
    this.isEditMode = false;
    this.selectedAppointmentId = 0;

    this.newAppointment = {
      patientId: '',
      doctorId: '',
      appointmentDate: '',
      status: 'Scheduled'
    };
  }
}