import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Doctor } from '../../services/doctor';

@Component({
  selector: 'app-doctors',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './doctors.html',
  styleUrl: './doctors.css'
})
export class Doctors {
  doctors: any[] = [];
  errorMessage = '';
  searchText = '';

  role = localStorage.getItem('role');

  isEditMode = false;
  selectedDoctorId = 0;

  newDoctor = {
    doctorName: '',
    specialization: '',
    experienceYears: ''
  };

  constructor(private doctorService: Doctor) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  isAdmin(): boolean {
    return this.role === 'Admin';
  }

  loadDoctors(): void {
    this.doctorService.getDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
      },
      error: () => {
        this.errorMessage = 'Unable to load doctors';
      }
    });
  }

  get filteredDoctors(): any[] {
    if (!this.searchText) {
      return this.doctors;
    }

    const search = this.searchText.toLowerCase();

    return this.doctors.filter(doctor =>
      doctor.doctorName.toLowerCase().includes(search) ||
      doctor.specialization.toLowerCase().includes(search)
    );
  }

  saveDoctor(): void {
    if (
      !this.newDoctor.doctorName ||
      !this.newDoctor.specialization ||
      !this.newDoctor.experienceYears
    ) {
      this.errorMessage = 'Please add all doctor details';
      return;
    }

    if (Number(this.newDoctor.experienceYears) < 0) {
      this.errorMessage = 'Experience years cannot be negative';
      return;
    }

    if (this.isEditMode) {
      this.updateDoctor();
      return;
    }

    this.doctorService.addDoctor(this.newDoctor).subscribe({
      next: () => {
        this.loadDoctors();
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Unable to add doctor';
      }
    });
  }

  editDoctor(doctor: any): void {
    this.isEditMode = true;
    this.selectedDoctorId = doctor.doctorId;

    this.newDoctor = {
      doctorName: doctor.doctorName,
      specialization: doctor.specialization,
      experienceYears: doctor.experienceYears
    };
  }

  updateDoctor(): void {
    this.doctorService.updateDoctor(this.selectedDoctorId, this.newDoctor).subscribe({
      next: () => {
        this.loadDoctors();
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Unable to update doctor';
      }
    });
  }

  deleteDoctor(id: number): void {
    if (!confirm('Delete this doctor?')) {
      return;
    }

    this.doctorService.deleteDoctor(id).subscribe({
      next: () => {
        this.loadDoctors();
      },
      error: () => {
        this.errorMessage = 'Unable to delete doctor';
      }
    });
  }

  resetForm(): void {
    this.errorMessage = '';
    this.isEditMode = false;
    this.selectedDoctorId = 0;

    this.newDoctor = {
      doctorName: '',
      specialization: '',
      experienceYears: ''
    };
  }
}