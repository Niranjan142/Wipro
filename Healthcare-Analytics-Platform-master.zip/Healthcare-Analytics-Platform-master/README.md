# Healthcare Analytics Platform

## Project Overview

Healthcare Analytics Platform is a full-stack healthcare management application built using ASP.NET Core Web API, Angular, Entity Framework Core, and SQL Server.

The application enables healthcare organizations to manage patients, doctors, and appointments efficiently while providing analytics and secure role-based access.

---

## Features

### Authentication & Security

* JWT Authentication
* Role-Based Access Control (Admin / Doctor)
* Angular Route Guards
* Secure API Communication

### Dashboard

* Patient Statistics
* Doctor Statistics
* Appointment Statistics
* Patients by Gender Analytics
* Doctors by Specialization Analytics
* Appointments by Status Analytics
* Light/Dark Theme Support

### Patient Management

* Add Patient
* Update Patient Details
* Delete Patient
* Search Patients
* Export Patient Data to Excel
* Form Validation

### Doctor Management

* Add Doctor
* Update Doctor Details
* Delete Doctor
* Search Doctors
* Experience Tracking

### Appointment Management

* Schedule Appointments
* Update Appointments
* Cancel Appointments
* Search Appointments
* Appointment Status Management
* Future Date Validation
* Status Indicators (Scheduled, Completed, Cancelled)


---

## Technology Stack

### Backend

* ASP.NET Core Web API
* Entity Framework Core
* SQL Server
* JWT Authentication

### Frontend

* Angular
* TypeScript
* HTML
* CSS

### Tools

* Visual Studio 2026
* Visual Studio Code
* Swagger UI
* GitHub

---

## Database Entities

### Patients

* PatientId
* FullName
* Age
* Gender
* PhoneNumber
* Email
* Address

### Doctors

* DoctorId
* DoctorName
* Specialization
* ExperienceYears

### Appointments

* AppointmentId
* PatientId
* DoctorId
* AppointmentDate
* Status

### Users

* UserId
* Username
* Password
* Role

---

## Project Architecture

Angular Frontend

↓

ASP.NET Core Web API

↓

Entity Framework Core

↓

SQL Server Database

---

## Unit Testing

Implemented Tests:

1. Add Patient Test
2. Get All Patients Test
3. Delete Patient Test

Test Results:

* Passed: 3
* Failed: 0

---

## Clone the Repository

To clone this project to your local machine:

```bash
git clone <repository-url>
```

Navigate to the project directory:

```bash
cd HealthcareAnalyticsPlatform
```

---

## Setup Instructions

### Backend Setup

1. Open the solution in Visual Studio.
2. Update the SQL Server connection string in `appsettings.json`.
3. Apply database migrations:

```powershell
Update-Database
```

4. Run the ASP.NET Core Web API.

### Frontend Setup

1. Navigate to the Angular project folder:

```bash
cd healthcare-analytics-ui
```

2. Install dependencies:

```bash
npm install
```

3. Start the Angular application:

```bash
ng serve
```

4. Open the application in your browser:

```text
http://localhost:4200
```

---

## Future Enhancements

* Email Notifications
* Doctor Scheduling
* Cloud Deployment
* Advanced Healthcare Analytics
