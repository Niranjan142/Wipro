﻿using HealthcareAnalytics.API.Data;
using HealthcareAnalytics.API.Models;
using HealthcareAnalytics.API.Services;
using Microsoft.EntityFrameworkCore;

namespace HealthcareAnalytics.Tests
{
    public class PatientServiceTests
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task AddPatient_ShouldAddPatientSuccessfully()
        {
            var context = GetDbContext();
            var service = new PatientService(context);

            var patient = new Patient
            {
                FullName = "Test Patient",
                Age = 25,
                Gender = "Male",
                PhoneNumber = "9876543210",
                Email = "test@gmail.com",
                Address = "Delhi"
            };

            var result = await service.AddPatient(patient);

            Assert.NotNull(result);
            Assert.Equal("Test Patient", result.FullName);
            Assert.Single(context.Patients);
        }

        [Fact]
        public async Task GetAllPatients_ShouldReturnPatients()
        {
            var context = GetDbContext();
            var service = new PatientService(context);

            context.Patients.Add(new Patient
            {
                FullName = "Patient One",
                Age = 30,
                Gender = "Female",
                PhoneNumber = "9876543211",
                Email = "one@gmail.com",
                Address = "Mumbai"
            });

            context.Patients.Add(new Patient
            {
                FullName = "Patient Two",
                Age = 40,
                Gender = "Male",
                PhoneNumber = "9876543212",
                Email = "two@gmail.com",
                Address = "Pune"
            });

            await context.SaveChangesAsync();

            var patients = await service.GetAllPatients();

            Assert.Equal(2, patients.Count);
        }

        [Fact]
        public async Task DeletePatient_ShouldDeletePatientSuccessfully()
        {
            var context = GetDbContext();
            var service = new PatientService(context);

            var patient = new Patient
            {
                FullName = "Delete Patient",
                Age = 28,
                Gender = "Male",
                PhoneNumber = "9876543213",
                Email = "delete@gmail.com",
                Address = "Chandigarh"
            };

            context.Patients.Add(patient);
            await context.SaveChangesAsync();

            var result = await service.DeletePatient(patient.PatientId);

            Assert.True(result);
            Assert.Empty(context.Patients);
        }
    }
}