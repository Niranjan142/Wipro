﻿CREATE DATABASE HealthcareAnalyticsDB;
GO

USE HealthcareAnalyticsDB;
GO

CREATE TABLE Patients
(
    PatientId INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(MAX) NOT NULL,
    Age INT NOT NULL,
    Gender NVARCHAR(MAX) NOT NULL,
    PhoneNumber NVARCHAR(MAX) NOT NULL,
    Email NVARCHAR(MAX) NOT NULL,
    Address NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME2 NOT NULL
);
GO

CREATE TABLE Doctors
(
    DoctorId INT IDENTITY(1,1) PRIMARY KEY,
    DoctorName NVARCHAR(MAX) NOT NULL,
    Specialization NVARCHAR(MAX) NOT NULL,
    ExperienceYears INT NOT NULL
);
GO

CREATE TABLE Appointments
(
    AppointmentId INT IDENTITY(1,1) PRIMARY KEY,
    PatientId INT NOT NULL,
    DoctorId INT NOT NULL,
    AppointmentDate DATETIME2 NOT NULL,
    Status NVARCHAR(MAX) NOT NULL,

    CONSTRAINT FK_Appointments_Patients_PatientId
    FOREIGN KEY (PatientId) REFERENCES Patients(PatientId),

    CONSTRAINT FK_Appointments_Doctors_DoctorId
    FOREIGN KEY (DoctorId) REFERENCES Doctors(DoctorId)
);
GO

CREATE TABLE Users
(
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(MAX) NOT NULL,
    Password NVARCHAR(MAX) NOT NULL,
    Role NVARCHAR(MAX) NOT NULL
);
GO

INSERT INTO Users (Username, Password, Role)
VALUES
('admin', 'admin123', 'Admin'),
('doctor1', 'doc123', 'Doctor');
GO

INSERT INTO Patients (FullName, Age, Gender, PhoneNumber, Email, Address, CreatedAt)
VALUES
('Chetan Khajuria', 22, 'Male', '9876543210', 'chetan@gmail.com', 'Jammu', GETDATE()),
('Rohit Sharma', 28, 'Male', '9876543211', 'rohit@gmail.com', 'HP', GETDATE());
GO

INSERT INTO Doctors (DoctorName, Specialization, ExperienceYears)
VALUES
('Dr. Amit Singh', 'Cardiologist', 8),
('Dr. Priya Sharma', 'Dermatologist', 5);
GO

INSERT INTO Appointments (PatientId, DoctorId, AppointmentDate, Status)
VALUES
(1, 1, DATEADD(DAY, 1, GETDATE()), 'Scheduled'),
(2, 2, DATEADD(DAY, 2, GETDATE()), 'Scheduled');
GO