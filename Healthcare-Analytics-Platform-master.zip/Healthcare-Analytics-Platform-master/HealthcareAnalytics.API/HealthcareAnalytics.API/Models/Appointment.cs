﻿using System.ComponentModel.DataAnnotations;

namespace HealthcareAnalytics.API.Models
{
    public class Appointment
    {
        public int AppointmentId { get; set; }

        [Required]
        public int PatientId { get; set; }

        [Required]
        public int DoctorId { get; set; }

        [Required]
        public DateTime AppointmentDate { get; set; }

        [Required]
        public string Status { get; set; } = "Scheduled";

        public Patient? Patient { get; set; }

        public Doctor? Doctor { get; set; }
    }
}