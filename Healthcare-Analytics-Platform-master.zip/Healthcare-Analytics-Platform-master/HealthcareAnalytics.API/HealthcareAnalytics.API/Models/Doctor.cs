﻿using System.ComponentModel.DataAnnotations;

namespace HealthcareAnalytics.API.Models
{
    public class Doctor
    {
        public int DoctorId { get; set; }

        [Required]
        public string DoctorName { get; set; }

        [Required]
        public string Specialization { get; set; }

        public int ExperienceYears { get; set; }

        public ICollection<Appointment>? Appointments { get; set; }
    }
}