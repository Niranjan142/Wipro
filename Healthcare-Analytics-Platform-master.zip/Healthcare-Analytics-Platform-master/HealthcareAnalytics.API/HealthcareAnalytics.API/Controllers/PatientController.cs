﻿using HealthcareAnalytics.API.Models;
using HealthcareAnalytics.API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HealthcareAnalytics.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
  
    public class PatientController : ControllerBase
    {
        private readonly IPatientService _patientService;

        public PatientController(IPatientService patientService)
        {
            _patientService = patientService;
        }

        [HttpGet]
        public async Task<IActionResult> GetPatients()
        {
            var patients = await _patientService.GetAllPatients();
            return Ok(patients);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPatientById(int id)
        {
            var patient = await _patientService.GetPatientById(id);

            if (patient == null)
            {
                return NotFound("Patient not found");
            }

            return Ok(patient);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddPatient(Patient patient)
        {
            var addedPatient = await _patientService.AddPatient(patient);
            return Ok(addedPatient);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdatePatient(int id, Patient patient)
        {
            var updatedPatient = await _patientService.UpdatePatient(id, patient);

            if (updatedPatient == null)
            {
                return NotFound("Patient not found");
            }

            return Ok(updatedPatient);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeletePatient(int id)
        {
            var isDeleted = await _patientService.DeletePatient(id);

            if (!isDeleted)
            {
                return NotFound("Patient not found");
            }

            return Ok("Patient deleted successfully");
        }
    }
}