﻿using HealthcareAnalytics.API.Models;
using HealthcareAnalytics.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace HealthcareAnalytics.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorController : ControllerBase
    {
        private readonly IDoctorService _doctorService;

        public DoctorController(IDoctorService doctorService)
        {
            _doctorService = doctorService;
        }

        [HttpGet]
        public async Task<IActionResult> GetDoctors()
        {
            var doctors = await _doctorService.GetAllDoctors();
            return Ok(doctors);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetDoctorById(int id)
        {
            var doctor = await _doctorService.GetDoctorById(id);

            if (doctor == null)
            {
                return NotFound("Doctor not found");
            }

            return Ok(doctor);
        }

        [HttpPost]
        public async Task<IActionResult> AddDoctor(Doctor doctor)
        {
            var addedDoctor = await _doctorService.AddDoctor(doctor);
            return Ok(addedDoctor);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDoctor(int id, Doctor doctor)
        {
            var updatedDoctor = await _doctorService.UpdateDoctor(id, doctor);

            if (updatedDoctor == null)
            {
                return NotFound("Doctor not found");
            }

            return Ok(updatedDoctor);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDoctor(int id)
        {
            var isDeleted = await _doctorService.DeleteDoctor(id);

            if (!isDeleted)
            {
                return NotFound("Doctor not found");
            }

            return Ok("Doctor deleted successfully");
        }
    }
}