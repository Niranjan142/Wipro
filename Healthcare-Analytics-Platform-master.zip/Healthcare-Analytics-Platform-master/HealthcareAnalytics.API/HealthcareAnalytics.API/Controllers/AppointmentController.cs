﻿using HealthcareAnalytics.API.Models;
using HealthcareAnalytics.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace HealthcareAnalytics.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentService _appointmentService;

        public AppointmentController(IAppointmentService appointmentService)
        {
            _appointmentService = appointmentService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAppointments()
        {
            var appointments = await _appointmentService.GetAllAppointments();
            return Ok(appointments);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAppointmentById(int id)
        {
            var appointment = await _appointmentService.GetAppointmentById(id);

            if (appointment == null)
            {
                return NotFound("Appointment not found");
            }

            return Ok(appointment);
        }

        [HttpPost]
        public async Task<IActionResult> AddAppointment(Appointment appointment)
        {
            try
            {
                var addedAppointment = await _appointmentService.AddAppointment(appointment);
                return Ok(addedAppointment);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAppointment(int id, Appointment appointment)
        {
            try
            {
                var updatedAppointment = await _appointmentService.UpdateAppointment(id, appointment);

                if (updatedAppointment == null)
                {
                    return NotFound("Appointment not found");
                }

                return Ok(updatedAppointment);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAppointment(int id)
        {
            var isDeleted = await _appointmentService.DeleteAppointment(id);

            if (!isDeleted)
            {
                return NotFound("Appointment not found");
            }

            return Ok("Appointment deleted successfully");
        }
    }
}