﻿using HealthcareAnalytics.API.Data;
using HealthcareAnalytics.API.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthcareAnalytics.API.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly ApplicationDbContext _context;

        public AppointmentService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<object>> GetAllAppointments()
        {
            var appointments = await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor)
                .Select(a => new
                {
                    a.AppointmentId,
                    a.PatientId,
                    PatientName = a.Patient.FullName,
                    a.DoctorId,
                    DoctorName = a.Doctor.DoctorName,
                    DoctorSpecialization = a.Doctor.Specialization,
                    a.AppointmentDate,
                    a.Status
                })
                .ToListAsync();

            return appointments.Cast<object>().ToList();
        }

        public async Task<object?> GetAppointmentById(int id)
        {
            var appointment = await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor)
                .Where(a => a.AppointmentId == id)
                .Select(a => new
                {
                    a.AppointmentId,
                    a.PatientId,
                    PatientName = a.Patient.FullName,
                    a.DoctorId,
                    DoctorName = a.Doctor.DoctorName,
                    DoctorSpecialization = a.Doctor.Specialization,
                    a.AppointmentDate,
                    a.Status
                })
                .FirstOrDefaultAsync();

            return appointment;
        }

        public async Task<Appointment> AddAppointment(Appointment appointment)
        {
            var patientExists = await _context.Patients
                .AnyAsync(p => p.PatientId == appointment.PatientId);

            if (!patientExists)
            {
                throw new Exception("Invalid PatientId. Patient does not exist.");
            }

            var doctorExists = await _context.Doctors
                .AnyAsync(d => d.DoctorId == appointment.DoctorId);

            if (!doctorExists)
            {
                throw new Exception("Invalid DoctorId. Doctor does not exist.");
            }

            _context.Appointments.Add(appointment);
            await _context.SaveChangesAsync();

            return appointment;
        }

        public async Task<Appointment?> UpdateAppointment(int id, Appointment appointment)
        {
            var existingAppointment = await _context.Appointments.FindAsync(id);

            if (existingAppointment == null)
            {
                return null;
            }

            var patientExists = await _context.Patients
                .AnyAsync(p => p.PatientId == appointment.PatientId);

            if (!patientExists)
            {
                throw new Exception("Invalid PatientId. Patient does not exist.");
            }

            var doctorExists = await _context.Doctors
                .AnyAsync(d => d.DoctorId == appointment.DoctorId);

            if (!doctorExists)
            {
                throw new Exception("Invalid DoctorId. Doctor does not exist.");
            }

            existingAppointment.PatientId = appointment.PatientId;
            existingAppointment.DoctorId = appointment.DoctorId;
            existingAppointment.AppointmentDate = appointment.AppointmentDate;
            existingAppointment.Status = appointment.Status;

            await _context.SaveChangesAsync();

            return existingAppointment;
        }

        public async Task<bool> DeleteAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);

            if (appointment == null)
            {
                return false;
            }

            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}