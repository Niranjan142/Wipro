﻿using HealthcareAnalytics.API.Models;

namespace HealthcareAnalytics.API.Services
{
    public interface IDoctorService
    {
        Task<List<Doctor>> GetAllDoctors();
        Task<Doctor?> GetDoctorById(int id);
        Task<Doctor> AddDoctor(Doctor doctor);
        Task<Doctor?> UpdateDoctor(int id, Doctor doctor);
        Task<bool> DeleteDoctor(int id);
    }
}