﻿using HealthcareAnalytics.API.Models;

namespace HealthcareAnalytics.API.Services
{
    public interface IAppointmentService
    {
        Task<List<object>> GetAllAppointments();
        Task<object?> GetAppointmentById(int id);
        Task<Appointment> AddAppointment(Appointment appointment);
        Task<Appointment?> UpdateAppointment(int id, Appointment appointment);
        Task<bool> DeleteAppointment(int id);
    }
}