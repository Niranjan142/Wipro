﻿using HealthcareAnalytics.API.Models;

namespace HealthcareAnalytics.API.Services
{
    public interface IPatientService
    {
        Task<List<Patient>> GetAllPatients();
        Task<Patient?> GetPatientById(int id);
        Task<Patient> AddPatient(Patient patient);
        Task<Patient?> UpdatePatient(int id, Patient patient);
        Task<bool> DeletePatient(int id);
    }
}